
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>


// Functions
void inventory_creation();

bool check_donation_textfile_exist();

void print_inventory();

void initialize_inventory();

void read_inventory();

void search();

void bubble_sort();

void update_donation();

void write_inventory();

void write_distribution();


// create a struct to store the inventory
struct inventory {
    char name_of_supply[100];
    char supply_code[3];
    char donator_country[100];
    int no_of_shipments;
    float quantity_received;
};
struct inventory inventory_list[5];
struct distribution_list {
    char supply_code[3];
    float quantity;
};
struct distribution_list write_dist;

int main() {
    printf("\n========= COVID-19 DONATION MANAGEMENT SYSTEM ===========\n");
    int choice;

    while (1) {
        printf("\n1. Inventory Creation \n");
        printf("2. Update Donation Quantities \n");
        printf("3. Search Donations by Donation Code \n");
        printf("4. List Of All Donations and Distributed Quantities \n");
        printf("5. Exit \n");
        printf("\nEnter your choice : ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: {
                // Inventory Creation
                inventory_creation();
                break;
            }
            case 2: {
                // Update Donation Quantities
                update_donation();
                break;
            }
            case 3: {
                // Search Donations by Donation Code
                search();
                break;
            }
            case 4: {
                // List Of All Donations and Their Distributed Quantities
                bubble_sort();
                break;
            }
            case 5:
                printf("*******--  System Shutdown --*******\n");
                exit(0);    // terminates the complete program execution
            default:
                printf("\n\n****-- Enter Correct Input! --****\n\n");
        }
    }
    printf("\n\n\t\t***-- Have A Nice Day! --***\n\n\n");
    return 0;
}
void inventory_creation() {
    if (check_donation_textfile_exist()) {
        printf("\n***-- Donation Text File Already Exist! --***\n");
        read_inventory();
        print_inventory();
        return;
    } else {
        FILE *fp;
        fp = fopen("donation.txt", "w");
        if (fp == NULL) {
            printf("\n***-- Error in Opening File! --***\n");
            return;
        } else {
            initialize_inventory();
            print_inventory();
            printf("\n***-- Donation Text File Created Successfully! --***\n");
            fclose(fp);
        }
    }
}

bool check_donation_textfile_exist() {
    FILE *fp;
    fp = fopen("donation.txt", "r");
    if (fp == NULL) {
        return false;
    } else {
        return true;
    }
}

void initialize_inventory() {
    // if donation.txt does not exist then create a new text file and store the data in the struct array
    FILE *fp;
    fp = fopen("donation.txt", "w");
    if (fp == NULL) {
        printf("\n***-- Error in Opening File! --***\n");
        return;
    } else {
        strcpy(inventory_list[0].name_of_supply, "ContactlessThermometer");
        strcpy(inventory_list[0].supply_code, "CT");
        strcpy(inventory_list[0].donator_country, "Japan");
        inventory_list[0].no_of_shipments = 1;
        inventory_list[0].quantity_received = 1.2;
        strcpy(inventory_list[1].name_of_supply, "HandSanitizer");
        strcpy(inventory_list[1].supply_code, "HS");
        strcpy(inventory_list[1].donator_country, "USA");
        inventory_list[1].no_of_shipments = 1;
        inventory_list[1].quantity_received = 3.5;
        strcpy(inventory_list[2].name_of_supply, "FaceMask");
        strcpy(inventory_list[2].supply_code, "FM");
        strcpy(inventory_list[2].donator_country, "China");
        inventory_list[2].no_of_shipments = 2;
        inventory_list[2].quantity_received = 120.0;
        strcpy(inventory_list[3].name_of_supply, "SurgicalMask");
        strcpy(inventory_list[3].supply_code, "SM");
        strcpy(inventory_list[3].donator_country, "China");
        inventory_list[3].no_of_shipments = 2;
        inventory_list[3].quantity_received = 38.0;
        strcpy(inventory_list[4].name_of_supply, "OxygenMask");
        strcpy(inventory_list[4].supply_code, "OM");
        strcpy(inventory_list[4].donator_country, "SaudiArabia");
        inventory_list[4].no_of_shipments = 2;
        inventory_list[4].quantity_received = 9.0;
        // write the struct array to the text file
        for (int i = 0; i < 5; i++) {
            fprintf(fp, "%s\t%s\t%s\t%d\t%f\n", inventory_list[i].name_of_supply, inventory_list[i].supply_code,
                    inventory_list[i].donator_country, inventory_list[i].no_of_shipments,
                    inventory_list[i].quantity_received);
        }
        fclose(fp);
    }

}

void read_inventory() {
    // if donation.txt exits then read donation.txt file and store the data in the struct array
    if (check_donation_textfile_exist()) {
        FILE *fp;
        fp = fopen("donation.txt", "r");
        if (fp == NULL) {
            printf("\nError in Opening File!\n");
            return;
        } else {
            // read the text file and store the data in the struct array
            FILE *fp;
            fp = fopen("donation.txt", "r");
            for (int i = 0; i < 5; i++) {
                fscanf(fp, "%s", inventory_list[i].name_of_supply);
                fscanf(fp, "%s", inventory_list[i].supply_code);
                fscanf(fp, "%s", inventory_list[i].donator_country);
                fscanf(fp, "%d", &inventory_list[i].no_of_shipments);
                fscanf(fp, "%f", &inventory_list[i].quantity_received);
            }
            fclose(fp);
        }
    }

}

void print_inventory() {
    printf("\n||Name of Supply||      ||Supply Code||  ||Donator||    ||No. of Shipment||  ||Quantity Received (millions)||\n");
    printf("---------------------------------------------------------------------------------------------------------------\n");
    printf("%s%10s%17s%16d%26.3f\n", inventory_list[0].name_of_supply, inventory_list[0].supply_code,
           inventory_list[0].donator_country, inventory_list[0].no_of_shipments, inventory_list[0].quantity_received);
    printf("---------------------------------------------------------------------------------------------------------------\n");
    printf("%s%19s%16s%17d%26.3f\n", inventory_list[1].name_of_supply, inventory_list[1].supply_code,
           inventory_list[1].donator_country, inventory_list[1].no_of_shipments, inventory_list[1].quantity_received);
    printf("---------------------------------------------------------------------------------------------------------------\n");
    printf("%s%24s%17s%16d%26.3f\n", inventory_list[2].name_of_supply, inventory_list[2].supply_code,
           inventory_list[2].donator_country, inventory_list[2].no_of_shipments, inventory_list[2].quantity_received);
    printf("---------------------------------------------------------------------------------------------------------------\n");
    printf("%s%20s%17s%16d%26.3f\n", inventory_list[3].name_of_supply, inventory_list[3].supply_code,
           inventory_list[3].donator_country, inventory_list[3].no_of_shipments, inventory_list[3].quantity_received);
    printf("---------------------------------------------------------------------------------------------------------------\n");
    printf("%s%22s%20s%13d%26.3f\n", inventory_list[4].name_of_supply, inventory_list[4].supply_code,
           inventory_list[4].donator_country, inventory_list[4].no_of_shipments, inventory_list[4].quantity_received);
    printf("---------------------------------------------------------------------------------------------------------------\n");
}

void update_donation() 
{
    read_inventory();
    char search_code[3];
    float quantity;
    printf("Enter the supply code: ");
    scanf("%s", search_code);
    for (int i = 0; i < 5; i++) 
    {
        if (strcmp(inventory_list[i].supply_code, search_code) == 0) {
            printf("------------------------------------------------------\n");
            printf(" Name of Supply: %s\n Supply Code: %s\n Donator: %s\n No. of shipment:%d\n Quantity Received (millions): %.3f\n",
                   inventory_list[i].name_of_supply, inventory_list[i].supply_code,
                   inventory_list[i].donator_country, inventory_list[i].no_of_shipments,
                   inventory_list[i].quantity_received);
            printf("------------------------------------------------------\n");
            printf("Do you want to donate supplies to other countries or receive donations from other countries?\n");
            printf("1. DONATE\n");
            printf("2. RECEIVED\n");
        
            int choice;
            scanf("%d", &choice);
            
            if (choice == 1) 
            {
                printf("Enter the quantity to donate: ");
                scanf("%f", &quantity);
                // check if the quantity is greater than the quantity received
                if(quantity > inventory_list[i].quantity_received)
                {
                    printf("\n***-- Error: Stock Unavailable for that amount! --***\n");
                    return;
                }
                inventory_list[i].quantity_received -= quantity;
                write_dist.quantity = quantity;
                strcpy(write_dist.supply_code, inventory_list[i].supply_code);
                printf("\n***-- Donation Successful! --***\n");
            } else if (choice == 2) 
            {
                printf("Enter the quantity to receive: ");
                scanf("%f", &quantity);
                inventory_list[i].quantity_received += quantity;
                printf("\n***-- Received Successful! --***\n");
            } else 
            {
                printf("***-- Invalid choice! --***\n");
            }
                
            
        }
        


        
    }
        
    

    write_inventory();
    write_distribution();
}

void write_inventory() {
    FILE *f;
    f = fopen("donation.txt", "w");
    for (int i = 0; i < 5; i++) {
        fprintf(f, "%s %s %s %d %f\n", inventory_list[i].name_of_supply, inventory_list[i].supply_code,
                inventory_list[i].donator_country, inventory_list[i].no_of_shipments,
                inventory_list[i].quantity_received);
    }
    fclose(f);
}

void write_distribution() {
    FILE *f;
    f = fopen("dist.txt", "a");
    fprintf(f, "%s %f\n", write_dist.supply_code, write_dist.quantity);
    fclose(f);
}

void search() {
    read_inventory();
    char search_code[3];
    printf("Enter the supply code to search: ");
    scanf("%s", search_code);
    for (int i = 0; i < 5; i++) {
        if (strcmp(inventory_list[i].supply_code, search_code) == 0) {
            printf("\n-------------------------------------------------\n");
            printf("Name of Supply: %s\nSupply Code: %s\nDonator: %s\nNo. of shipment:%d\nQuantity Received (millions): %.3f\n",
                   inventory_list[i].name_of_supply, inventory_list[i].supply_code,
                   inventory_list[i].donator_country, inventory_list[i].no_of_shipments,
                   inventory_list[i].quantity_received);
            printf("--------------------------------------------------\n");
        }
    }
}

void bubble_sort() {1

    int ch = 0;
    int lines = 0;
    FILE *fp;
    fp = fopen("dist.txt", "r");
    if (fp == NULL) {
        printf("\n***Error in Opening File!***\n");
        return;
    }
    while (!feof(fp)) {
        ch = fgetc(fp);
        if (ch == '\n') {
            lines++;
        }
    }
    struct distribution_list dist[lines];
    // read the text file and store the data in the struct array
    FILE *f;
    f = fopen("dist.txt", "r");
    for (int i = 0; i < lines; i++) {
        fscanf(f, "%s", dist[i].supply_code);
        fscanf(f, "%f", &dist[i].quantity);
    }
    fclose(f);
    // print the unsorted array
    printf("----------------------Unsorted-------------------------------\n");
    for (int i = 0; i < lines; i++) {
        printf("%s   %.3f\n", dist[i].supply_code, dist[i].quantity);

    }
    printf("-------------------------------------------------------------\n");
    // bubble sort in descending order
    for (int i = 0; i < lines; i++) {
        for (int j = 0; j < lines - 1; j++) {
            if (dist[j].quantity < dist[j + 1].quantity) {
                struct distribution_list temp;
                temp = dist[j];
                dist[j] = dist[j + 1];
                dist[j + 1] = temp;
            }
        }
    }
    // print the sorted data
    printf("-----------------------Sorted-----------------------------\n");
    for (int i = 0; i < lines; i++) {
        printf("%s   %.3f\n", dist[i].supply_code, dist[i].quantity);
         
    }
    printf("----------------------------------------------------------\n");
    fclose(fp);
    
}
